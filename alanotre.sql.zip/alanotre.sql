-- phpMyAdmin SQL Dump
-- version 3.4.10.1deb1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Ven 07 Mars 2014 à 08:17
-- Version du serveur: 5.5.35
-- Version de PHP: 5.3.10-1ubuntu3.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `alanotre`
--

-- --------------------------------------------------------

--
-- Structure de la table `favoris_user`
--

CREATE TABLE IF NOT EXISTS `favoris_user` (
  `fav_id_user` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `favori_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fav_id_user`),
  KEY `user_id` (`user_id`),
  KEY `favori_id` (`favori_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Contenu de la table `favoris_user`
--

INSERT INTO `favoris_user` (`fav_id_user`, `user_id`, `favori_id`) VALUES
(1, 1, 2),
(2, 1, 3),
(3, 1, 4),
(4, 2, 3),
(5, 2, 4),
(6, 3, 4);

-- --------------------------------------------------------

--
-- Structure de la table `favoris_wine`
--

CREATE TABLE IF NOT EXISTS `favoris_wine` (
  `fav_id_wine` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wine_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fav_id_wine`),
  KEY `user_id` (`user_id`),
  KEY `wine_id` (`wine_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `proposition`
--

CREATE TABLE IF NOT EXISTS `proposition` (
  `prop_id` smallint(11) unsigned NOT NULL AUTO_INCREMENT,
  `prop_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `prop_send_user_mail` varchar(255) NOT NULL,
  `prop_receive_user_mail` varchar(255) NOT NULL,
  `prop_receive_user_firstname` varchar(255) NOT NULL,
  `prop_send_wine_id` smallint(11) unsigned NOT NULL,
  `prop_send_wine_name` varchar(255) NOT NULL,
  `prop_send_wine_img` varchar(255) NOT NULL,
  `prop_receive_wine_id` smallint(11) unsigned NOT NULL,
  `prop_receive_wine_name` varchar(255) NOT NULL,
  `prop_receive_wine_img` varchar(255) NOT NULL,
  PRIMARY KEY (`prop_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Contenu de la table `proposition`
--

INSERT INTO `proposition` (`prop_id`, `prop_date`, `prop_send_user_mail`, `prop_receive_user_mail`, `prop_receive_user_firstname`, `prop_send_wine_id`, `prop_send_wine_name`, `prop_send_wine_img`, `prop_receive_wine_id`, `prop_receive_wine_name`, `prop_receive_wine_img`) VALUES
(1, '2014-03-07 05:49:26', 'mail1@mail.com', 'mail1@mail.com', 'Lulu', 1, 'Saint-Émilion', 'saint-emilion.jpg', 9, 'Entre-deux-mers', 'entre-deux-mers.jpg'),
(2, '2014-03-07 05:54:19', 'mail1@mail.com', 'mail1@mail.com', 'Lulu', 11, 'Moselle rosé', 'moselle-rose.jpg', 12, 'Beaujolais Cercié rouge', 'beaujolais.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `userwine`
--

CREATE TABLE IF NOT EXISTS `userwine` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_firstname` varchar(50) NOT NULL,
  `user_lastname` varchar(50) NOT NULL,
  `user_mail` varchar(100) NOT NULL,
  `user_mdp` varchar(50) NOT NULL,
  `user_street` varchar(100) NOT NULL,
  `user_town` varchar(50) NOT NULL,
  `user_cp` int(10) unsigned NOT NULL,
  `user_img` varchar(50) NOT NULL DEFAULT 'user_avatar',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_mail` (`user_mail`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `userwine`
--

INSERT INTO `userwine` (`user_id`, `user_firstname`, `user_lastname`, `user_mail`, `user_mdp`, `user_street`, `user_town`, `user_cp`, `user_img`) VALUES
(1, 'Lulu', 'Libélule', 'mail1@mail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '34 rue des oublis', 'Paris', 75000, '1.png'),
(2, 'Floyd', 'Moneymaker', 'mail2@mail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '99 Rue de l''argent', 'Paris', 75000, '2.png'),
(3, 'Mario', 'Boboli', 'mail3@mail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '45 rue de la confiance', 'Paris', 75000, '3.png'),
(4, 'Théo', 'Popid', 'mail4@mail.com', '7110eda4d09e062aa5e4a390b0a572ac0d2c0220', '12 rue des abeilles', 'Paris', 75000, '4.png');

-- --------------------------------------------------------

--
-- Structure de la table `wine`
--

CREATE TABLE IF NOT EXISTS `wine` (
  `wine_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `wine_name` varchar(50) NOT NULL,
  `wine_time_add` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  `wine_value` int(11) NOT NULL DEFAULT '0',
  `wine_origin` varchar(100) DEFAULT NULL,
  `wine_cepage` varchar(100) DEFAULT NULL,
  `wine_millesime` int(4) NOT NULL,
  `wine_quantitee` int(2) NOT NULL DEFAULT '1',
  `wine_conseil` varchar(255) DEFAULT NULL,
  `wine_img` varchar(50) NOT NULL,
  `user_wine_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`wine_id`),
  KEY `user_wine_id` (`user_wine_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Contenu de la table `wine`
--

INSERT INTO `wine` (`wine_id`, `wine_name`, `wine_time_add`, `wine_value`, `wine_origin`, `wine_cepage`, `wine_millesime`, `wine_quantitee`, `wine_conseil`, `wine_img`, `user_wine_id`) VALUES
(1, 'Saint-Émilion', '2014-03-07 05:42:24', 100, 'Dordogne', 'Merlot', 2005, 1, 'A déguster avec des champignons, du gibier à plume ou un petit bout de cantal !', 'saint-emilion.jpg', 1),
(3, 'Aloxe-Corton', '2014-03-02 13:14:05', 150, 'Bourgogne', 'Chardonnay', 2008, 1, 'De préférence en apéritif, avec des toats de saumon fumé et des gambas !', 'aloxe-corton.jpg', 2),
(4, 'Côté Rotie', '2014-03-03 10:42:14', 100, 'Rhône', 'Viognier', 2011, 1, 'Décanter le vin une voire deux heures avant le service !', 'cote-rotie.jpg', 3),
(7, 'Muscat du Cap Corse', '2014-03-06 14:16:29', 200, 'Provence', 'Muscat à petits grains', 2007, 1, 'À déguster avec une petite salade d’endive au bleu de corse !', 'muscat-cap-corse.jpg', 1),
(8, 'Barsac', '2014-02-04 09:39:16', 140, 'Rhône', 'Bordeaux', 2006, 2, ' Décanter le vin une voire deux heures avant le service !', 'barsac.jpg', 2),
(9, 'Entre-deux-mers', '2014-02-05 17:28:48', 170, 'Bordeaux', 'Carbernet', 2012, 1, 'Ce vin se déguste à une températeur de 15¨C, dans un verre de type “bordeaux”.', 'entre-deux-mers.jpg', 3),
(10, 'Pomerol', '2014-02-12 14:16:32', 160, 'Bordeaux', 'Merlot', 2012, 1, 'Agneau, filet de boeuf oie rôtie… tout y passe !', 'pomerol.jpg', 4),
(11, 'Moselle rosé', '2014-03-07 05:42:42', 80, 'Lorraine', 'Pinot', 2009, 3, 'Prenez soin de bien régler votre armoire à vin de service entre 14° et 16°C.', 'moselle-rose.jpg', 1),
(12, 'Beaujolais Cercié rouge', '2014-03-07 05:42:34', 140, 'Beaujolais', 'Garnay', 2005, 2, 'A déguster avec des champignons, du gibier à plume ou un petit bout de cantal !', 'beaujolais.jpg', 2),
(13, 'Château-Chalon', '2014-03-05 11:27:12', 480, 'Jura', 'Savagnon', 2000, 2, 'A déguster avec des tourtes au comté ou des rillettes de truites !', 'chateau-chalon.jpg', 3),
(14, 'Cabardès Rosé', '2013-12-23 08:17:36', 70, 'Roussillon', 'Grenache', 2005, 1, 'La température de service requise est entre 8 et 11 degrés.', 'cabardes-rose', 3),
(15, 'Chateau Grillet', '2013-12-11 23:00:00', 180, 'Jura', 'Viognier', 2007, 1, 'On peut l’accorder avec des volailles pochées ou des poissons en sauces.', 'chateau-grillet.jpg', 4),
(16, 'Faugeres blanc', '2014-03-02 23:00:00', 230, 'Languedoc', 'Clairette', 2008, 3, 'A déguster avec un très bon poulet aux langoustines ! Un délice !', 'faugeres-blanc.jpg', 3),
(17, 'Seyssel Mousseux', '2014-02-03 11:08:00', 230, 'Savoie', 'Chasselas', 2002, 1, 'On peut l’accorder avec des volailles pochées ou des poissons en sauces.', 'seyssel-mousseux.jpg', 3);

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `favoris_user`
--
ALTER TABLE `favoris_user`
  ADD CONSTRAINT `favoris_user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `userwine` (`user_id`),
  ADD CONSTRAINT `favoris_user_ibfk_2` FOREIGN KEY (`favori_id`) REFERENCES `userwine` (`user_id`);

--
-- Contraintes pour la table `favoris_wine`
--
ALTER TABLE `favoris_wine`
  ADD CONSTRAINT `favoris_wine_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `userwine` (`user_id`),
  ADD CONSTRAINT `favoris_wine_ibfk_2` FOREIGN KEY (`wine_id`) REFERENCES `wine` (`wine_id`);

--
-- Contraintes pour la table `wine`
--
ALTER TABLE `wine`
  ADD CONSTRAINT `wine_ibfk_1` FOREIGN KEY (`user_wine_id`) REFERENCES `userwine` (`user_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
